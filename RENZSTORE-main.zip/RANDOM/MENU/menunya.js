const chalk = require('chalk')
const fs = require('fs')

global.fakelink = "https://instagram.com/akangfirmanqrew" // bebas asal jan hapus

global.menunya = (pushname, prefix, hituet) =>{
	return `Halo Kak 👋 ${pushname}
Saya ${namabot}, Saya Adalah Bot WhatsApp .

╭✄┈┈┈⟬ *INFO-BOT* ⟭
┆❐ Creator : ${namaowner}
┆❐ Bot Name : ${namabot}
┆❐ Runtime : ${runtime(process.uptime())}
┆❐ Time : ${xtime}
┆❐ Date : ${xdate}
╰──────────◇

○ Ketik *#semuamenu* = Menampilkan semua menu
○ Ketik *#sewa* = Menampilkan harga sewa
○ Ketik *#buyprem* = Menampilkan harga Premium
○ Ketik *#owner* = Menampilkan owner bot

_KATA-KATA HARI INI_ 

*JUJUR ITU SOPAN .*
*BERBAGI ITU BAIK*

___________________________


╭─❒ 「 *OTHER MENU* 」 
│
│❐ !tribun-news (NON AKTIF)
│❐ !indozone-news (NON AKTIF)
│❐ !kompas-news (NON AKTIF)
│❐ !okezone-news (NON AKTIF)
│❐ !sindo-news (NON AKTKIF)
│❐ !tempo-news (NON AKTIF)
│❐ !antara-news (NON AKTIF)
│❐ !merdeka-news (NON AKTIF)
│
╰❒

///TIDAK AKIF\\\
╭─❒ 「 *CECAN MENU* 」 
│
│❐ !china
│❐ !indonesia
│❐ !malaysia
│❐ !thailand
│❐ !korea
│❐ !japan
│❐ !vietnam
│❐ !jenni
│❐ !jiiso
│❐ !lisa
│❐ !rose
│
╰❒

╭─❒ 「 *COGAN MENU* 」 
│
│❐ !wuyifan
│❐ !suga
│❐ !parkchanyeol
│❐ !ohsehun
│❐ !luhan
│❐ !kimtaehyung
│❐ !kimseok
│❐ !kimnanjoon
│❐ !kimminseok
│❐ !kimjunmyeon
│❐ !kimjong
│❐ !kimjondae
│❐ !jungkook
│❐ !jimin
│❐ !jhope
│❐ !huangzitao
│❐ !dohkyungsoo
│❐ !baekhyung
│
╰❒
///TIDAK AKIF\\\

📝 SUBSCRIBE YT CREATOR : #
`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})